# http://stackoverflow.com/questions/22943894/class-labels-in-pandas-scattermatrix
def factor_scatter_matrix(df, factor, palette=None):
    '''Create a scatter matrix of the variables in df, with differently colored
    points depending on the value of df[factor].
    inputs:
        df: pandas.DataFrame containing the columns to be plotted, as well 
            as factor.
        factor: string or pandas.Series. The column indicating which group 
            each row belongs to.
        palette: A list of hex codes, at least as long as the number of groups.
            If omitted, a predefined palette will be used, but it only includes
            9 groups.
    '''
    import matplotlib.colors
    import numpy as np
    from pandas.tools.plotting import scatter_matrix
    from scipy.stats import gaussian_kde

    if isinstance(factor, basestring):
        factor_name = factor #save off the name
        factor = df[factor] #extract column
        df = df.drop(factor_name,axis=1) # remove from df, so it 
        # doesn't get a row and col in the plot.

    classes = list(set(factor))

    if palette is None:
        palette = ['#e41a1c', '#377eb8', '#4eae4b', 
                   '#994fa1', '#ff8101', '#fdfc33', 
                   '#a8572c', '#f482be', '#999999']

    color_map = dict(zip(classes,palette))

    if len(classes) > len(palette):
        raise ValueError('''Too many groups for the number of colors provided.
                            We only have {} colors in the palette, but you have {}
                            groups.'''.format(len(palette), len(classes)))

    colors = factor.apply(lambda group: color_map[group])
    axarr = scatter_matrix(df,figsize=(12,12),marker='o',c=colors,diagonal=None)

    '''
    for rc in xrange(len(df.columns)):
        for group in classes:
            y = df[factor == group].iloc[:,rc].values
            #gkde = gaussian_kde(y)
            ind = np.linspace(y.min(), y.max(), 1000)
            #axarr[rc][rc].plot(ind, gkde.evaluate(ind),c=color_map[group])
            axarr[rc][rc].plot(ind, ind,c=color_map[group])
    '''

    return axarr, color_map


def boxplot_clusters(df, col, target, figsize=(12,12)):
    """
    Boxplots
    """
    col_data =  df[[col,target]]
    dd = []

    K = df[target].unique().tolist()
    for i in K:
        data_i = col_data[col_data[target]==i]
        data_i = data_i.values.tolist()
        dd.append(data_i)
        
    fig,ax = plt.subplots(figsize=figsize)
    bp = ax.boxplot(dd, positions = K, widths = 0.6, patch_artist=True)

    for flier in bp['fliers']:
        flier.set(marker='v', color='#FF0000', alpha=0.5)
        flier.set

    for median in bp['medians']:
        median.set(color='#191970', linewidth=5)

    colors = ['#1E90FF', '#ADD8E6','#FFFACD','#008000', '#FFD700', '#FFA500', 'pink']
    for patch, color, whisker in zip(bp['boxes'], colors, bp['whiskers']):
        patch.set_facecolor(color)
        whisker.set(linewidth=1)
        
    plt.title(col)
    plt.tight_layout()